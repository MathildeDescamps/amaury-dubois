<?php

    require_once ONEA_CORE_ABS_PATH . '/core-dashboard/rest/rest.php';

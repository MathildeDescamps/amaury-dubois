<?php

include_once ONEA_CORE_SHORTCODES_PATH . '/icon-with-text/functions.php';
include_once ONEA_CORE_SHORTCODES_PATH . '/icon-with-text/icon-with-text.php';
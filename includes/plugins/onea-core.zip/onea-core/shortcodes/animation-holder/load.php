<?php

include_once ONEA_CORE_SHORTCODES_PATH . '/animation-holder/functions.php';
include_once ONEA_CORE_SHORTCODES_PATH . '/animation-holder/animation-holder.php';
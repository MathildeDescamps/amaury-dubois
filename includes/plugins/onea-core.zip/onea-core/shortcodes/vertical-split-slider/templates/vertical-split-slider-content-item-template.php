<div class="eltdf-vss-ms-section" <?php echo onea_elated_get_inline_attrs($content_data); ?> <?php onea_elated_inline_style($content_style);?>>
	<?php echo do_shortcode($content); ?>
</div>
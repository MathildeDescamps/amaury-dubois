<?php

include_once ONEA_CORE_SHORTCODES_PATH . '/icon/functions.php';
include_once ONEA_CORE_SHORTCODES_PATH . '/icon/icon.php';
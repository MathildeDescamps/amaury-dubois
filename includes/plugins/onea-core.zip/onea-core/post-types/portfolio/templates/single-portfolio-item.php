<?php

get_header();

onea_elated_get_title();

do_action('onea_elated_action_before_main_content');

onea_core_get_single_portfolio();

get_footer();
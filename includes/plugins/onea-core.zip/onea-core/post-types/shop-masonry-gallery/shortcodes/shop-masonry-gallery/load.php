<?php

require_once 'shop-masonry-gallery.php';
require_once 'helper-functions.php';
<?php

include_once ONEA_CORE_CPT_PATH . '/shop-masonry-gallery/shop-masonry-gallery-register.php';
include_once ONEA_CORE_CPT_PATH . '/shop-masonry-gallery/helper-functions.php';
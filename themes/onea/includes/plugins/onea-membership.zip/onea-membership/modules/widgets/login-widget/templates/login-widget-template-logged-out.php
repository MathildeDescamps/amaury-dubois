<a href="#" class="eltdf-login-opener">
    <span class="eltdf-login-text"><?php esc_html_e('SIGN IN', 'onea-membership'); ?></span>
</a>
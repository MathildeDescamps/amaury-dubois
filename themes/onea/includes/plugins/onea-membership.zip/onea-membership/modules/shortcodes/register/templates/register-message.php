<div class="eltdf-register-notice">
	<p class="eltdf-register-notice-title"><?php echo esc_html($message); ?></p>
</div>
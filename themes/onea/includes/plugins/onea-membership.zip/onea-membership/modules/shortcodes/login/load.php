<?php

include_once ONEA_MEMBERSHIP_SHORTCODES_PATH . '/login/functions.php';
include_once ONEA_MEMBERSHIP_SHORTCODES_PATH . '/login/login.php';